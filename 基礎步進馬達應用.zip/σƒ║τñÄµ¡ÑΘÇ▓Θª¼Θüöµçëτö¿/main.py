# 使用於Python3
from vendor.StepMotor import StepMotor
import time

stepmotor = StepMotor()

stepmotor.forward(10/1000,200)